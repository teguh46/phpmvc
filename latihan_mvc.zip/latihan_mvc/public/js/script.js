$(function() {
    $('.tombolTambahData').on('click', function () {
        $('#formModalLabel').html('Tambah Data Mahasiswa');
        $('.form-group button[type=submit]').html('Tambah Data');
    });

    $('.tampilModalUbah').on('click', function() {
        $('#formModalLabel').html('Ubah Data Mahasiswa');
        $('.form-group button[type=submit]').html('Ubah Data');
        $('.modal-body form').attr('action', 'http://localhost:8060/latihan_mvc/public/mahasiswa/ubah');

        const id = $(this).data('id');

        $.ajax({
            url: 'http://localhost:8060/latihan_mvc/public/mahasiswa/getubah',
            data: {id : id},
            method: 'post',
            dataType: 'json',
            success: function(data){
                $('#nama_mhs').val(data.nama_mhs);
                $('#nim_mhs').val(data.nim_mhs);
                $('#email_mhs').val(data.email_mhs);
                $('#jurusan_mhs').val(data.jurusan_mhs);
                $('#id').val(data.id);
            }
        });
    });

});
