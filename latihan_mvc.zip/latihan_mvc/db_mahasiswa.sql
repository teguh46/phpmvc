-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2022 at 09:30 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_mahasiswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_mhs`
--

CREATE TABLE `tb_mhs` (
  `id` int(50) NOT NULL,
  `nama_mhs` varchar(255) NOT NULL,
  `nim_mhs` varchar(255) NOT NULL,
  `email_mhs` varchar(255) NOT NULL,
  `jurusan_mhs` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_mhs`
--

INSERT INTO `tb_mhs` (`id`, `nama_mhs`, `nim_mhs`, `email_mhs`, `jurusan_mhs`) VALUES
(21, 'Teguh subagyo', '1503040072', 'teguhsubagyo11@gmail.com', 'Teknik Informatika'),
(30, 'aldo wait', '1503040088', 'aldo@gmail.com', 'Teknik Elektro'),
(43, 'ok mamanv', '123', 'efsfdsf@gmail.com', 'Teknik Informatika'),
(44, 'aji', '2011900002', 'das@gmail.com', 'Teknik Informatika'),
(45, 'asd', '2011900002', 'das@gmail.com', 'Teknik Kimia'),
(46, 'asd', '123', 'efsfdsf@gmail.com', 'Teknik Informatika'),
(47, 'jhk', '2011900002', 'das@gmail.com', 'Teknik Informatika'),
(48, 'jhkj', '123', 'hu.sain@gmail.com', 'Teknik Informatika'),
(49, 'jhkh', '1503040072', 'teguhsubagyo11@gmail.com', 'Teknik Informatika'),
(50, 'asd', '123', 'efsfdsf@gmail.com', 'Teknik Informatika'),
(51, 'ok', '123', 'husain@gmail.com', 'Teknik Informatika');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_mhs`
--
ALTER TABLE `tb_mhs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_mhs`
--
ALTER TABLE `tb_mhs`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
