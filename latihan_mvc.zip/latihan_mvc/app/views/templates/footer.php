<div class="row">
                            <div class="col-lg-12">
                                <div class="footer">
                                    <p>2022 - <?= date ("Y")?> © Teguh Subagyo Ltd</p>
                                </div>
                            </div>
                        </div>
                        <!-- /# footer -->
                    </section>
                </div>
            </div>
        </div>
        <!-- jquery vendor -->
        <script src="<?=BASEURL?>/js/lib/jquery.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/jquery.nanoscroller.min.js"></script>
        <!-- nano scroller -->
        <script src="<?=BASEURL?>/js/lib/menubar/sidebar.js"></script>
        <script src="<?=BASEURL?>/js/lib/preloader/pace.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/jquery.nicescroll.min.js"></script>
        
        <!-- sidebar -->
        <script src="<?=BASEURL?>/js/lib/bootstrap.min.js"></script>
        <!-- bootstrap -->

        <script src="<?=BASEURL?>/js/lib/calendar-2/moment.latest.min.js"></script>
        <!-- scripit init-->
        <script src="<?=BASEURL?>/js/lib/calendar-2/semantic.ui.min.js"></script>
        <!-- scripit init-->
        <script src="<?=BASEURL?>/js/lib/calendar-2/prism.min.js"></script>
        <!-- scripit init-->
        <script src="<?=BASEURL?>/js/lib/calendar-2/pignose.calendar.min.js"></script>
        <!-- scripit init-->
        <script src="<?=BASEURL?>/js/lib/calendar-2/pignose.init.js"></script>
        <!-- scripit init-->


        <script src="<?=BASEURL?>/js/lib/weather/jquery.simpleWeather.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/weather/weather-init.js"></script>
        <script src="<?=BASEURL?>/js/lib/circle-progress/circle-progress.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/circle-progress/circle-progress-init.js"></script>
        <script src="<?=BASEURL?>/js/lib/chartist/chartist.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/chartist/chartist-init.js"></script>
        <script src="<?=BASEURL?>/js/lib/sparklinechart/jquery.sparkline.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/sparklinechart/sparkline.init.js"></script>
        <script src="<?=BASEURL?>/js/lib/owl-carousel/owl.carousel.min.js"></script>
        <script src="<?=BASEURL?>/js/lib/owl-carousel/owl.carousel-init.js"></script>
        <script src="<?=BASEURL?>/js/scripts.js"></script>
        <!-- scripit init-->
        <script src="<?=BASEURL?>/js/scripts.js"></script>
        <script src="<?=BASEURL?>/js/script.js"></script>
        
  </body>
    </body>

</html>