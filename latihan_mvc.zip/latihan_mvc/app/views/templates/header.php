<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?=$data['judul']?></title>
        <!-- ================= Favicon ================== -->
        <!-- Standard -->
        <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
        <!-- Retina iPad Touch Icon-->
        <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
        <!-- Retina iPhone Touch Icon-->
        <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
        <!-- Standard iPad Touch Icon-->
        <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
        <!-- Standard iPhone Touch Icon-->
        <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
        <!-- Styles -->
        <link href="<?=BASEURL?>/css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/chartist/chartist.min.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/font-awesome.min.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/themify-icons.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/owl.carousel.min.css" rel="stylesheet" />
        <link href="<?=BASEURL?>/css/lib/owl.theme.default.min.css" rel="stylesheet" />
        <link href="<?=BASEURL?>/css/lib/weather-icons.css" rel="stylesheet" />
        <link href="<?=BASEURL?>/css/lib/menubar/sidebar.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/bootstrap.min.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/lib/helper.css" rel="stylesheet">
        <link href="<?=BASEURL?>/css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
            <div class="nano">
                <div class="nano-content">
                    <ul>
                        <div class="logo"><a href="index.html"><!-- <img src="assets/images/logo.png" alt="" /> --><span>MVC</span></a></div>
                        <li class="label">Main</li>
                        <li class="">
                                <a href="<?=BASEURL?>/public">
                                    <i class="ti-home"></i>Dashboard
                                    <span class="badge badge-primary"></span>
                                </a>
                        </li>

                        <li class="label">Apps</li>

                        <li>
                            <a href="<?=BASEURL?>/mahasiswa">
                                <i class="ti-server"></i> Data Mahasiswa </a>
                        </li>

                        <li>
                            <a href="<?=BASEURL?>/about">
                                <i class="ti-info-alt"></i> About</a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <!-- /# sidebar -->

        <div class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="float-left">
                            <div class="hamburger sidebar-toggle">
                                <span class="line"></span>
                                <span class="line"></span>
                                <span class="line"></span>
                            </div>
                        </div>
                        <div class="float-right">
                            <ul>
                                <li class="header-icon dib"><span class="user-avatar"><?=$data['nama'];?> <i class="ti-angle-down f-s-10"></i></span>
                                    <div class="drop-down dropdown-profile">
                                        <div class="dropdown-content-heading">
                                            <span class="text-left">Selamat datang</span>
                                            <p class="trial-day"><?=$data['nama']?></p>
                                        </div>
                                        <div class="dropdown-content-body">
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /# header -->

 
