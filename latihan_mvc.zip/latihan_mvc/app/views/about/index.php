<div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 p-r-0 title-margin-right">
                            <div class="page-header">
                                <div class="page-title">
                                    <h1>Hello, <span>Selamat Datang di Website</span></h1>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                        <div class="col-lg-4 p-l-0 title-margin-left">
                            <div class="page-header">
                                <div class="page-title">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?=BASEURL;?>"> <?=$data['judul2']?> </a></li>
                                        <li class="breadcrumb-item active"><?=$data['judul']?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->
                    <section id="main-content">
                        <div class="row">
                            <div class="col-lg-11">
                                <div class="card bg-light">
                                    <div class="testimonial-widget-one">
                                        <div class="owl-carousel owl-theme">
                                            <div class="item">
                                                <div class="testimonial-content">
                                                    <div class="testimonial-text">
                                                        <i class="fa fa-quote-left"></i> <b>ABOUT ME </b> <i class="fa fa-quote-right"></i>
                                                    </div>
                                                    <img class="testimonial-author-img" src="<?=BASEURL?>/images/gwe.jpg" alt="" />
                                                    <div class="testimonial-author">Nama saya <?= $data['nama']?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                           

                                <div class="card">
                                    <div class="card-title m-t-22">
                                        <h4>ABOUT US </h4>
                                    </div>

                                    <div class="recent-comment m-t-15">
                                        <div class="media">
                                            <div class="media-body">
                                            <p>Hubungi kami ke :</p><br>
                                                <p>Jalan Raya Cingebul, Lumbir, Banyumas</p>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="recent-comment m-t-22">
                                        <div class="media">
                                            <div class="icon-container">
                                                <span class="ti-google"></span><span class="icon-name"> Google Plus</span>
                                            </div>

                                            <div class="icon-container">
                                                <span class="ti-linkedin"></span><span class="icon-name"> Linkedin</span>
                                            </div>

                                            <div class="icon-container">
                                                <span class="ti-twitter"></span><span class="icon-name"> Twitter</span>
                                            </div>

                                            <div class="icon-container">
                                                <span class="ti-instagram"></span><span class="icon-name"> Instagram</span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- /# card -->
                            </div>
                            <!-- /# column -->
                        </div>
                        <!-- /# row -->
                    <!-- /# Content -->
