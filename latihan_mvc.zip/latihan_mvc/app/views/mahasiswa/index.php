<div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 p-r-0 title-margin-right">
                            <div class="page-header">
                                <div class="page-title">
                                    <h1>Hello, <span>Selamat Datang di Website</span></h1>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                        <div class="col-lg-4 p-l-0 title-margin-left">
                            <div class="page-header">
                                <div class="page-title">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?=BASEURL;?>"> <?=$data['judul2']?></a></li>
                                        <li class="breadcrumb-item active"><?=$data['judul']?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->
                    <section id="main-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-title">

                                        <div class="card-content">
                                            <div class="col-13">
                                                <?php Flasher::flash() ?>
                                            </div>
                                        </div>
                                        <!-- /# Pesan flash alert -->

                                        <h4>DATA MAHASISWA</h4>
                                            <div class="col-lg-6 text-left">
                                                <a href="#formModalTambahData" data-target="#formModal" data-toggle="modal" title="Tambah Data Mahasiswa" class="btn btn-primary btn-outline btn-rounded m-b-10 m-l-5 tombolTambahData"> 
                                                Tambah Data Mahasiswa </a>
                                            </div>

                                          <div class="col-lg-6">
                                            <form action="<?=BASEURL;?>/mahasiswa/cari" method="post">
                                                <div class="form-group">
                                                    <div class="input-group input-group-rounded">
                                                        <input type="text" placeholder="Cari ..." name="keyword" id="keyword"  class="form-control" autocomplete="off">
                                                            <span class="input-group-btn">
                                                              <button class="btn btn-primary btn-group-right" type="submit" id="tombolCari"><i class="ti-search"></i> Cari </button></span>
                                                    </div>
                                                  </div>
                                              </form>
                                            </div>
                                          </div>
                                           <!-- /# Pencarian Data -->

                                    <div class="col-lg-7 body-center">
                                           <div class="table-responsive">
                                                <ul class="list-group">
                                                     <?php foreach ( $data ['mhs'] as $mhs ) : ?>
                                                        <li class="list-group-item">
                                                            <?= $mhs['nama_mhs'];?>

                                                            <a href="<?=BASEURL;?>/mahasiswa/detail/<?= $mhs['id'];?>" class="badge badge-success float-right ml-1"> 
                                                            <span class="ti-eye"> Detail </span></a>

                                                            <a href="<?=BASEURL;?>/mahasiswa/hapus/<?= $mhs['id'];?>" class="badge badge-danger float-right ml-1"> 
                                                            <span class="ti-trash" onclick="return confirm('Apakah yakin hapus data?')"> Hapus </span></a>

                                                            <a href="<?=BASEURL;?>/mahasiswa/ubah/<?= $mhs['id'];?>" class="badge badge-info float-right ml-1 tampilModalUbah" data-id="<?=$mhs['id']?>" data-target="#formModal" data-toggle="modal"> 
                                                            <span class="ti-pencil"> Ubah </span></a>
                                                        </li>
                                                    <?php endforeach;?>
                                                </ul>
                                            </div>
                                    </div>


                        <div class="inbox-body text-center">
                        <!-- Modal -->
                            <div aria-hidden="true" role="dialog" tabindex="-1" id="formModal" class="modal fade">
                              <div class="modal-dialog">
                                <div class="modal-content text-left">
                                  <div class="modal-header">
                                    <button aria-hidden="true" data-dismiss="modal" class="close" type="button"><i class="ti-close"></i></button>
                                    <h4 class="modal-title" id="formModalLabel">Tambah Data Mahasiswa</h4>
                                  </div>

                                  <div class="modal-body">
                                    <form class="form-horizontal" action="<?=BASEURL?>/mahasiswa/formModalTambah" method="post">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label" for="id" hidden>id</label>
                                        <div class="col-lg-10">
                                          <input type="text" placeholder="Masukan Nama" id="id" name="id" class="form-control" hidden>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-lg-4 control-label" for="nama_mhs">Nama</label>
                                        <div class="col-lg-10">
                                          <input type="text" pattern="[a-zA-Z ]+" title="Isikan Berupa Huruf" placeholder="Masukan Nama" id="nama_mhs" name="nama_mhs" class="form-control" required>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-lg-4 control-label" for="nim_mhs">Nim</label>
                                        <div class="col-lg-10">
                                          <input type="text" pattern="[0-9]+" title="Isikan Berupa Angka" placeholder="Masukan Nim" id="nim_mhs" name="nim_mhs" class="form-control" required>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-lg-4 control-label" for="email_mhs">Email</label>
                                        <div class="col-lg-10">
                                          <input type="email" placeholder="Masukan Email" id="email_mhs" name="email_mhs" class="form-control">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-lg-4 control-label">Jurusan</label>
                                            <div class="col-lg-10">
                                                    <select class="form-control" id="jurusan_mhs" name="jurusan_mhs" required>
                                                        <option value ="Teknik Informatika">Teknik Informatika</option>
                                                        <option value ="Teknik Sipil">Teknik Sipil</option>
                                                        <option value="Teknik Elektro">Teknik Elektro</option>
                                                        <option value="Teknik Mesin">Teknik Mesin</option>
                                                        <option value="Teknik Kimia">Teknik Kimia</option>
                                                      </select>
                                            </div>
                                      </div>

                                      <div class="form-group">
                                        <div class="col-lg-offset-4 col-lg-10">
                                        <button type="submit" value="submit" class="btn btn-success btn-outline btn-rounded m-b-10 m-l-5">Tambah Data</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                              <!-- /.modal-dialog -->
                            </div>
                        <!-- /.modal -->
                        </div>

