<div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 p-r-0 title-margin-right">
                            <div class="page-header">
                                <div class="page-title">
                                    <h1>Hello, <span>Selamat Datang di Website</span></h1>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                        <div class="col-lg-4 p-l-0 title-margin-left">
                            <div class="page-header">
                                <div class="page-title">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?=BASEURL?>"> <?=$data['judul2']?></a></li>
                                        <li class="breadcrumb-item active"><?=$data['judul']?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->
                    <section id="main-content">
                        <div class="row">
                            <div class="col-lg-7">
                                <div class="card">
                                    <div class="card-title">
                                    <h4>DATA MAHASISWA DETAIL</h4>

                                    </div>
                                    <div class="recent-comment m-t-15">
                                        <div class="media">
                                            <div class="media-body">
                                                <div class="card-body">
                                                    <h4 class="card-title"><?=$data['mhs']['nama_mhs']?></h4>
                                                    <h4 class="card-title"><?=$data['mhs']['nim_mhs']?></h4>
                                                    <h4 class="card-title"><?=$data['mhs']['email_mhs']?></h4>
                                                    <h4 class="card-title"><?=$data['mhs']['jurusan_mhs']?></h4>

                                                    <div class="recent-comment m-t-15">
                                                        <a href="<?=BASEURL;?>/mahasiswa" class="badge badge-dark">Kembali</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /# card -->
                            </div>
                            <!-- /# column -->
                        </div>
                        <!-- /# row -->
                    <!-- /# Content -->
                        

    