<?php

class Mahasiswa_model{
    private $table = 'tb_mhs';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllMahasiswa ()
    {
       $this->db->query('SELECT * FROM ' . $this->table);
       return $this->db->resultSet();
    }

    public function getMahasiswaById($id)
    {
        $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
        $this->db->bind('id', $id);
        return $this->db->single();
    }

    public function tambahDataMahasiswa($data)
    {
        $query = "INSERT INTO tb_mhs
                  VALUES
                  ('', :nama_mhs, :nim_mhs, :email_mhs, :jurusan_mhs)";
        $this->db->query($query);
        $this->db->bind("nama_mhs", $data["nama_mhs"]);
        $this->db->bind("nim_mhs", $data["nim_mhs"]);
        $this->db->bind("email_mhs", $data["email_mhs"]);
        $this->db->bind("jurusan_mhs", $data["jurusan_mhs"]);

        $this->db->execute();
        return $this->db->rowCount();
    }

    public function hapusDataMahasiswa($id)
    {
        $query = "DELETE FROM tb_mhs WHERE id = :id";
        $this->db->query($query);
        $this->db->bind('id', $id);

        $this->db->execute();
        return $this->db->rowCount();
    }

    public function ubahDataMahasiswa($data)
    {
        $query = "UPDATE tb_mhs SET
                        nama_mhs = :nama_mhs, 
                        nim_mhs = :nim_mhs, 
                        email_mhs =  :email_mhs,
                        jurusan_mhs = :jurusan_mhs
                  WHERE id = :id";

        $this->db->query($query);
        $this->db->bind("id", $data["id"]);
        $this->db->bind("nama_mhs", $data["nama_mhs"]);
        $this->db->bind("nim_mhs", $data["nim_mhs"]);
        $this->db->bind("email_mhs", $data["email_mhs"]);
        $this->db->bind("jurusan_mhs", $data["jurusan_mhs"]);
    
        $this->db->execute();
        return $this->db->rowCount();  
    }

    public function cariDataMahasiswa()
    {
        $keyword = $_POST['keyword'];
        $query = "SELECT * FROM tb_mhs WHERE nama_mhs LIKE :keyword";
        $this->db->query($query);
        $this->db->bind('keyword', "%$keyword%");
        return $this->db->resultSet();
    }
}