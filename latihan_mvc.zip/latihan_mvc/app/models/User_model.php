<?php

class User_model {
    private $nama = 'Teguh Subagyo';

    public function getUser()
    {
        return $this->nama;
    }
}