<?php

class About extends Controller {
    public function index($nama = 'Teguh Subagyo')
    {
        $data ['nama'] = $nama;
        $data ['judul2'] = 'Dashbord';
        $data ['judul'] = 'About Me';
        $this->view('templates/header', $data);
        $this->view('about/index', $data);
        $this->view('templates/footer');

    }
}